package com.ub.tfg.kukuicup.controller;

public class Controller {
	public Config config;
	public Controller(){
		config = new Config();
	}

}
