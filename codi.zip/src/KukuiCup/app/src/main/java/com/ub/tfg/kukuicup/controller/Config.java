package com.ub.tfg.kukuicup.controller;

public class Config {
    // Google Console APIs developer key
    // Replace this key with your's
    public static final String DEVELOPER_KEY = "AIzaSyCE1_gQBhYmVUrCkeHFjU7CvfBh15NZcCc";
     
    // YouTube video id
    public static final String YOUTUBE_VIDEO_CODE = "_PD7a1EWjsTc";

    //Dev Machine IP
    //public static final String LOCALHOST = "192.168.1.130/kukuicupbcn";
    public static final String LOCALHOST = "proyectonline.es/carlos";
    //public static final String LOCALHOST = "10.133.10.8";
}
